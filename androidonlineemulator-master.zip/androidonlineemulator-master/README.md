# ApkOnlone Android online emulator

This is a demo about how to write a web browser extensions using the ApkOnline android online emulator.

The android online emulator demo can be run here:

https://www.apkonline.net/runapk/create-androidapk.html?app=android_6.0_blank

Its integration to upload any APK is here:

https://www.apkonline.net/appdirect/filemanager.html

This is an android online emulator that can run the APK of an app. A free android online emulator from where any user can run the APK of an app using only the web browser.  Among the different existing user interface configurations, this web extension runs a tablet over Android 6.0 Marshmallow.

ApkOnline can simulate features such as device rotation, some hardware sensors and access to the phone buttons via a menu on the right side of the emulator. 

Video demo at:

[![ApkOnline android online emulator](http://img.youtube.com/vi/qMizbRGgny8/0.jpg)](http://www.youtube.com/watch?v=qMizbRGgny8 "ApkOnline android online emulator")


